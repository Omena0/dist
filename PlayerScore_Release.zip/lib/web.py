from flask import request, session
from urllib.parse import quote
from threading import Thread
import flask.logging
import time as t
import requests
import requests
import webview
import secrets
import logging
import socket
import flask
import os

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

os.environ['Path'] = ''

app:flask.Flask = flask.Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(16)

addr = requests.get('https://omena0.github.io/api/playerScore/host').text.strip().split(':')
addr = addr[0], int(addr[1])

redirect_uri = 'http://localhost:5001/'

oauth_url = f"https://discord.com/api/oauth2/authorize?client_id=1352987777784086588&redirect_uri={quote(redirect_uri)}&response_type=code&scope=identify"

username = None
token = None

def destroy():
    t.sleep(1)
    window.destroy()

@app.route('/')
def index():
    global token, username
    if "access_token" in session:
        token = session['access_token']
        Thread(target=destroy, daemon=True).start()
        return ""

    code = request.args.get("code")
    if not code:
        return flask.redirect(oauth_url)

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            # Add timeout to prevent hanging
            s.settimeout(10)  # 10 second timeout
            s.connect(addr)

            # Send the authentication data in the required format
            auth_message = f"login|{code}"
            s.sendall(auth_message.encode())

            # Receive response
            response_data = s.recv(4096).decode()

            # Split the response
            parts = response_data.split('|')

            # Check if response is in the expected format
            if parts[0] == "ok":
                # The server sends: ok|username|token
                username, token = parts[1:]
                session["access_token"] = token
                Thread(target=destroy, daemon=True).start()
                return ""
            else:
                # Error format: error|message
                error_message = parts[1] if len(parts) >= 2 else "Unknown error"
                return f"<h1>Authentication failed: {error_message}</h1>"

    except socket.timeout:
        return "<h1>Authentication timeout. Server did not respond within the time limit.</h1>"

    except Exception as e:
        return f"<h1>Authentication error: {str(e)}</h1>"

    return flask.redirect('/')

def login():
    global window
    Thread(target=app.run, args=('127.0.0.1', 5001, False), daemon=True).start()

    window = webview.create_window('Discord Authentication', oauth_url, width=800, height=600)
    webview.start(private_mode=False)

    with open(f'../PlayerScore/token.txt', 'w') as f:
        f.write(str(username+'|'+token) or "")

    return username, token

def authenticate():
    """Get Discord OAuth token only - actual server auth happens in player.py"""
    os.makedirs(f'../PlayerScore', exist_ok=True)

    # Try to load existing token and username
    if os.path.exists(f'../PlayerScore/token.txt'):
        with open(f'../PlayerScore/token.txt', 'r') as f:
            content = f.read().strip()
            if '|' in content:  # If file contains username|token format
                username, token = content.split('|', 1)
                if token:
                    return username, token

    # No valid token found, get a new one via OAuth
    username, token = login()

    if not token:
        print('[-] Failed to get Discord token')
        return None, None

    return username, token

