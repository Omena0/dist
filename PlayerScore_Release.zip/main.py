from system.lib.minescript import *
from threading import Thread


if 'guestsmp.xyz' in world_info().address:
    def chatGames():
        import chatGames
    Thread(target=chatGames,daemon=True).start()
    import player
    player.main()
