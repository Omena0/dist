from lib.web import authenticate, addr
from system.lib.minescript import *
import socket
import json
import time
import sys
import re
import os

if 'guestsmp' not in world_info().address:
    print("[!] Please only use this script on The Guest SMP.")
    exit(0)

os.environ['Path'] = ''

_printed = []
def print(*args, **kwargs):
    """Custom print function that prevents the chat listener from parsing our messages."""
    _printed.append(" ".join([str(m) for m in args]))
    echo(*args, **kwargs)

exit = os._exit
client_player = player_name()

s = socket.socket()

username = None  # Will be set during authentication
session_token = None

token_path = os.path.join(os.path.dirname(__file__), "session_token.json")

# Utils
def strip_color_codes(text):
    """Remove Minecraft color/formatting codes from text."""
    if not text:
        return text

    # First handle UTF-8 encoding of the § symbol (\u00c2\u00a7 sequence)
    # This matches the sequence of characters that make up the UTF-8 color codes
    text = re.sub(r'\u00c2\u00a7[\w\d]', '', text)

    # Then handle direct § symbol if present
    text = re.sub(r'\u00a7[\w\d]', '', text)

    # For literal § character if present
    text = re.sub(r'§[\w\d]', '', text)

    # Handle any remaining strange encodings by removing any unusual characters
    text = re.sub(r'[^\w\d\s\[\]\(\)\-\.,:;\'\"!@#$%^&*<>?/\\|{}=+~`]', '', text)

    return text

def recv(s, timeout=0.3):
    s.settimeout(timeout)
    all = b''
    try:
        while True:
            data = s.recv(1024)
            if not data:
                break
            all += data

    except socket.timeout: ...
    s.settimeout(None)

    return all

# Protocol
def fetch_players():
    s.sendall(b'get_players')

    players = recv(s)

    return players.decode().split('|')

def fetch_score(target:str):
    s.sendall(f'get_score|{target}'.encode())

    score = recv(s)

    return float(score.decode())

def submit_player(target: str, team=None, rank=None):
    """Submit a player with optional team and rank information"""
    target = strip_color_codes(target)
    if not target:
        return

    if team:
        team = strip_color_codes(team).strip('[]')
    if rank:
        rank = strip_color_codes(rank)

    if team and len(team) < 3:
        return

    if rank and len(rank) < 2:
        return

    if len(target) < 4:
        return

    if (team.startswith('DEBUG]:')
            or team.startswith('Meteor')
            or team.startswith('Server')
            or team.startswith('Coinflip')
            or team.startswith('BLISS')
        ):
        return

    if not team:
        s.sendall(f'add_player|{target}|{rank}'.encode())
        status = recv(s)
        if status == b'ok':
            print(f'[+] Added {f" {rank}" if rank else ""} {target} to player list')
        elif status == b'updated':
            print(f'[+] Updated {f" {rank}" if rank else ""} {target} in player list')
        players.append(target)
        return

    s.sendall(f'add_player_and_team|{target}|{rank}|{team}'.encode())
    status = recv(s)
    if status == b'ok':
        print(f'[+] Added [{team}] {f" {rank}" if rank else ""} {target} to player list')
    elif status == b'updated':
        print(f'[+] Updated [{team}] {f" {rank}" if rank else ""} {target} in player list')

    players.append(target)

def add_relationship(rel_type, target):
    """Add a relationship to a player"""
    target = strip_color_codes(target)
    if not target:
        return False

    players = fetch_players()

    if target not in players:
        print(f"[-] Player {target} not found")
        return False

    s.sendall(f'add_{rel_type}|{target}'.encode())
    status = recv(s)

    if status == b'ok':
        print(f"[+] Added {target} as {rel_type}")
        return True
    elif status == b'known':
        print(f"[!] {target} is already your {rel_type}")
        return True
    elif status == b'unknown':
        print(f"[-] Player {target} not found on server")
        return False
    else:
        print(f"[-] Error: {status.decode()}")
        return False

def remove_relationship(rel_type, target):
    """Remove a relationship from a player"""
    target = strip_color_codes(target)
    if not target:
        return False

    s.sendall(f'remove_{rel_type}|{target}'.encode())
    status = recv(s)

    if status == b'ok':
        print(f"[+] Removed {target} from your {rel_type}s")
        return True
    elif status == b'not_found':
        print(f"[!] {target} is not in your {rel_type}s list")
        return True
    else:
        print(f"[-] Error: {status.decode()}")
        return False

def get_player_info(target):
    """Get detailed info about a player"""
    target = strip_color_codes(target)
    if not target:
        return None

    s.sendall(f'get_player_info|{target}'.encode())
    response = recv(s)

    if response == b'unknown':
        print(f"[-] Player {target} not found")
        return None

    try:
        info = json.loads(response.decode())
        return info
    except:
        print(f"[-] Error parsing player info")
        return None

def search_players(term, search_type='all'):
    """Search for players and teams by partial name"""
    term = strip_color_codes(term)
    if not term:
        return None

    s.sendall(f'search_players|{term}|{search_type}'.encode())
    response = recv(s)

    # Check if response is empty
    if not response:
        return {"error": "No response from server"}

    try:
        # Parse the response as JSON
        results = json.loads(response.decode())
        return results
    except json.JSONDecodeError:
        # If not JSON, try to handle as plain text
        text_response = response.decode()

        # Check if it's our old format (pipe-separated list)
        if '|' in text_response:
            players = text_response.split('|')
            return {
                'search_term': term,
                'search_type': search_type,
                'results': players,
                'total_results': len(players),
                'team_data': {}
            }

        # If not a known format, return the raw response
        return {"error": f"Unexpected response: {text_response[:100]}..."}
    except Exception as e:
        print(f"[-] Error processing search results: {e}")
        return {"error": f"Error: {str(e)}"}

# Updated display_search_results function for simplified results
def display_search_results(term, search_type='all'):
    """Display search results with unified player list"""
    results = search_players(term, search_type)

    if not results or 'error' in results or not results.get('total_results', 0):
        print(f"[-] No results found for '{term}'")
        return

    print(f"\nSearch results for '{term}':")

    # Display player matches from the unified sorted list
    player_count = results.get('total_results', 0)
    player_results = results.get('results', [])

    if player_count > 0:
        # Show detailed info for the first (most relevant) result
        if player_results:
            top_player = player_results[0]
            player_info = get_player_info(top_player)

            if player_info:
                print(f"\n[TOP MATCH] {top_player}:")

                # Team information
                team = player_info.get('team')
                if team:
                    print(f"  Team: {team}")
                else:
                    print("  Team: None")

                # Relationship counts
                print(f"  Relationships:")
                print(f"    Friends: {len(player_info.get('friends', []))} players")
                print(f"    Enemies: {len(player_info.get('enemies', []))} players")
                print(f"    Allies: {len(player_info.get('allies', []))} players")
                print(f"    Associated: {len(player_info.get('associated', []))} players")

                # Show specific relationships if present (but condensed)
                if player_info.get('friends'):
                    print(f"  Friends: {', '.join(player_info['friends'][:5])}" +
                          (f" (+ {len(player_info['friends']) - 5} more)" if len(player_info['friends']) > 5 else ""))

                if player_info.get('enemies'):
                    print(f"  Enemies: {', '.join(player_info['enemies'][:5])}" +
                          (f" (+ {len(player_info['enemies']) - 5} more)" if len(player_info['enemies']) > 5 else ""))
            else:
                print(f'[-] Could not get player info')
                print(f"\n{top_player}")

        # Create a unified list of all other results (including teams)
        other_results = []

        # Add remaining players
        if len(player_results) > 1:
            for player in player_results[1:]:
                player_info = get_player_info(player)
                if player_info:
                    team_display = f"[{player_info['team']}]" if player_info.get('team') else ""
                    other_results.append(f"  - {player} {team_display}")
                else:
                    other_results.append(f"  - {player}")

        # Add team matches with [TEAM] prefix
        if 'team_data' in results and results['team_data']:
            for team, members in results['team_data'].items():
                member_count = len(members)
                other_results.append(f"  - [TEAM] {team} ({member_count} members)")

        # Display the unified list if there are any other results
        if other_results:
            print("\nOther matches:")
            for result in other_results:
                print(result)

def display_team_info(team_name):
    """Display comprehensive team information including relationships"""
    members = get_team_members(team_name)

    if not members:
        print(f"[-] No members found for team {team_name}")
        return

    print(f"\nTeam: {team_name} ({len(members)} members)")
    print("\nMembers:")

    # Get detailed info for each team member
    team_allies = set()
    enemy_counts = {}  # Track how many members consider each player an enemy

    # First pass - gather all relationship data
    for member in members:
        player_info = get_player_info(member)
        if not player_info:
            print(f"  - {member} (No information available)")
            continue

        # Add member's allies to team allies
        team_allies.update(player_info.get('allies', []))

        # Count enemies
        for enemy in player_info.get('enemies', []):
            enemy_counts[enemy] = enemy_counts.get(enemy, 0) + 1

        # Show relationships for this member
        ally_count = len(player_info.get('allies', []))
        enemy_count = len(player_info.get('enemies', []))
        friend_count = len(player_info.get('friends', []))

        print(f"  - {member} ({ally_count} allies, {enemy_count} enemies, {friend_count} friends)")

    # Filter enemies to only include those marked by at least 2 members
    team_enemies = [enemy for enemy, count in enemy_counts.items() if count >= 2]

    # Display team-wide relationships
    if team_allies:
        print("\nTeam allies:")
        for ally in sorted(team_allies):
            # Skip members of this team
            if ally in members:
                continue
            print(f"  - {ally}")

    if team_enemies:
        print("\nTeam enemies (marked by at least 2 members):")
        for enemy in sorted(team_enemies):
            # Skip members of this team
            if enemy in members:
                continue
            member_count = enemy_counts[enemy]
            consensus = (member_count / len(members)) * 100
            print(f"  - {enemy} (marked by {member_count}/{len(members)} members, {consensus:.1f}% consensus)")

def get_team_members(team):
    """Get members of a team"""
    team = strip_color_codes(team)
    if not team:
        return []

    s.sendall(f'get_team_members|{team}'.encode())
    response = recv(s)

    return response.decode().split('|') if response else []

def get_teams():
    """Get list of all teams"""
    s.sendall(b'get_teams')
    response = recv(s)

    return response.decode().split('|') if response else []

def get_stats(player) -> dict|None:
    """Get player statistics"""
    player = strip_color_codes(player)
    if not player:
        return None

    s.sendall(f'get_stats|{player}'.encode())
    response = recv(s)

    try:
        stats = json.loads(response.decode())
        return stats
    except json.JSONDecodeError:
        print(f"[-] Error parsing player stats")
        return None

def get_nearby_players():
    """Get nearby players"""
    return [i.name for i in get_players()]

def parse_command(argv):
    # Replace the command line parsing section with this enhanced version
    if not len(argv) > 1:
        return
    command = argv[1].lower()

    # Help command
    if command == "help" or command == "-h" or command == "--help":
        print("Available commands:")
        print("  score <player>")
        print("  info <player>")
        print("  friend <player>")
        print("  enemy <player>")
        print("  ally <player>")
        print("  associate <player>")
        print("  unfriend <player>")
        print("  unenemy <player>")
        print("  unally <player>")
        print("  unassociate <player>")
        print("  teams")
        print("  team <team>")
        print("  search <term>")
        print("  stats <player>")
        print("  near")
        print("  leaderboard (or lb)")
        exit(0)

    # Commands that require one additional argument
    if len(sys.argv) > 2:
        target = sys.argv[2]

        if command == "score":
            score = fetch_score(target)
            print(f"Score with {target}: {score}")
            exit(0)

        elif command == "info":
            info = get_player_info(target)
            if info:
                print(f"Player information for {target}:")

                # Team information
                team = info.get('team')
                if team:
                    print(f"  Team: {team}")
                    # Get team members
                    team_members = get_team_members(team)
                    print(f"  Teammates: {', '.join([m for m in team_members if m != target])}" if len(team_members) > 1 else "  No teammates")
                else:
                    print("  Team: None")

                # Updated relationship counts display with better formatting
                print(f"  Relationships:")
                print(f"    Friends: {len(info['friends'])} players" if info['friends'] else "    Friends: None")
                print(f"    Enemies: {len(info['enemies'])} players" if info['enemies'] else "    Enemies: None")
                print(f"    Allies: {len(info['allies'])} players" if info['allies'] else "    Allies: None")
                print(f"    Associated: {len(info['associated'])} players" if info['associated'] else "    Associated: None")

                # Show specific relationships if present
                if info['friends']:
                    print(f"  Friends: {', '.join(info['friends'])}")

                if info['enemies']:
                    print(f"  Enemies: {', '.join(info['enemies'])}")

                if info['allies']:
                    print(f"  Allies: {', '.join(info['allies'])}")

                if info['associated']:
                    print(f"  Associated: {', '.join(info['associated'])}")

                # Look for mutual relationships (players who have marked this player too)
                print("\n  Reciprocal relationships:")
                mutual_found = False

                for other_player in info['friends'] + info['enemies'] + info['allies'] + info['associated']:
                    other_info = get_player_info(other_player)
                    if not other_info:
                        continue

                    relationships = []
                    if target in other_info['friends']:
                        relationships.append("friend")
                    if target in other_info['enemies']:
                        relationships.append("enemy")
                    if target in other_info['allies']:
                        relationships.append("ally")
                    if target in other_info['associated']:
                        relationships.append("associated")

                    if relationships:
                        mutual_found = True
                        print(f"    {other_player} has marked you as: {', '.join(relationships)}")

                if not mutual_found:
                    print("    No reciprocal relationships found")
            else:
                print(f"[-] Could not find player: {target}")
            exit(0)

        elif command == "friend":
            add_relationship("friend", target)
            exit(0)

        elif command == "enemy":
            add_relationship("enemy", target)
            exit(0)

        elif command == "ally":
            add_relationship("ally", target)
            exit(0)

        elif command == "associate":
            add_relationship("associated", target)
            exit(0)

        elif command == "unfriend":
            remove_relationship("friend", target)
            exit(0)

        elif command == "unenemy":
            remove_relationship("enemy", target)
            exit(0)

        elif command == "unally":
            remove_relationship("ally", target)
            exit(0)

        elif command == "unassociate":
            remove_relationship("associated", target)
            exit(0)

        elif command == "team":
            members = get_team_members(target)
            if not members:
                print(f"[-] {team} does not exist. Do \\player search <query> to search for teams or players.")
                exit(0)

            print(f"Members of team {target}:")
            for member in members:
                print(f"  - {member}")
            exit(0)

        elif command == "search":
            display_search_results(target)
            exit(0)

        elif command == "stats":
            stats = get_stats(target)
            print(f"Statistics for {target}:")
            print(f' Added players: {stats["added_players"]}')
            print(f' Updated players: {stats["updated_players"]}')
            print(f' Added teams: {stats["added_teams"]}')
            print(f' Updated teams: {stats["updated_teams"]}')
            exit(0)

    if command == 'admin':
        # Check if user is authorized for admin commands
        if username not in {'omena0'}:
            print("[-] Nice try ;)")
            exit(0)

        if len(argv) < 3:
            print("[-] Admin command requires subcommand")
            print("Available admin commands:")
            print("  admin add_friend <source> <target>")
            print("  admin add_enemy <source> <target>")
            print("  admin add_ally <source> <target>")
            print("  admin associate <source> <target>")
            print("  admin remove_friend <source> <target>")
            print("  admin remove_enemy <source> <target>")
            print("  admin remove_ally <source> <target>")
            print("  admin unassociate <source> <target")
            print("  admin list_players")
            print("  admin reset_player <player>")
            print("  admin set_team <player> <team>")
            exit(0)

        subcommand = argv[2]

        # Handle relationship management commands
        relationship_commands = [
            'add_friend', 'add_enemy', 'add_ally', 'associate',
            'remove_friend', 'remove_enemy', 'remove_ally', 'unassociate'
        ]

        if subcommand in relationship_commands:
            if len(argv) < 5:
                print(f"[-] Admin {subcommand} requires source and target players")
                print(f"Usage: python player.py admin {subcommand} <source_player> <target_player>")
                exit(0)

            if subcommand == 'associate':
                subcommand = 'add_associated'
            elif subcommand == 'unassociate':
                subcommand = 'remove_associated'

            source = argv[3]
            target = argv[4]

            s.sendall(f'admin|{subcommand}|{source}|{target}'.encode())
            status = recv(s)

            if status == b'ok':
                print(f"[+] Admin: Successfully {subcommand.replace('_', 'ed ')} {target} {'to' if subcommand.startswith('add') else 'from'} {source}")
            elif status == b'already_exists':
                print(f"[!] {target} is already in {source}'s {subcommand.split('_')[1]}s list")
            elif status == b'not_found':
                print(f"[!] {target} is not in {source}'s {subcommand.split('_')[1]}s list")
            elif status == b'unknown_player':
                print(f"[-] One or both players don't exist")
            elif status == b'not_admin':
                print(f"[-] Server rejected admin privileges")
            else:
                print(f"[-] Error: {status.decode()}")

        elif subcommand == 'list_players':
            s.sendall(b'admin|list_players')
            response = recv(s)

            users = response.decode().split('|')
            print(f"[+] {len(users)} users registered:")
            for i, user in enumerate(users):
                print(f" {i+1}. {user}")

        elif subcommand == 'reset_player':
            if len(argv) < 4:
                print("[-] Admin reset_player requires player name")
                print("Usage: python player.py admin reset_player <player_name>")
                exit(0)

            target = argv[3]
            s.sendall(f'admin|reset_player|{target}'.encode())
            status = recv(s)

            if status == b'ok':
                print(f"[+] Reset all relationships for {target}")
            elif status == b'unknown_player':
                print(f"[-] Player {target} not found")
            else:
                print(f"[-] Error: {status.decode()}")

        elif subcommand == 'set_team':
            if len(argv) < 5:
                print("[-] Admin set_team requires player name and team name")
                print("Usage: python player.py admin set_team <player_name> <team_name>")
                exit(0)

            target = argv[3]
            team = argv[4]
            s.sendall(f'admin|set_team|{target}|{team}'.encode())
            status = recv(s)

            if status == b'ok':
                print(f"[+] Set {target}'s team to {team}")
            else:
                print(f"[-] Error: {status.decode()}")

        else:
            print(f"[-] Unknown admin subcommand: {subcommand}")
            print("Use '\\player admin' to see available admin commands")

        exit(0)

    # Commands that don't require additional arguments
    elif command == "teams":
        teams = get_teams()
        print("Available teams:")
        for i, team in enumerate(sorted(teams)):
            print(f" {i+1}. {team}")
        exit(0)

    elif command == "near":
        # Get nearby players
        nearby_players = get_nearby_players()

        if client_player in nearby_players:
            nearby_players.remove(client_player)

        if not nearby_players:
            print("[-] No players detected nearby")
            exit(0)

        # Check scores and separate into high, low and neutral
        high_score_players = []
        low_score_players = []

        for player in nearby_players:
            try:
                score = fetch_score(player)
                if score >= 2:
                    high_score_players.append((player, score))
                elif score <= -2.5:
                    low_score_players.append((player, score))

            except: ...

        if not high_score_players and not low_score_players:
            print("[-] No players with significant scores found.")
            exit(0)

        # Display results
        if high_score_players:
            for player, score in sorted(high_score_players, key=lambda x: x[1], reverse=True):
                player_info = get_player_info(player)
                player_info
                print(f"  + [{player_info.get('team','N/A')}] {player_info.get('rank','')} {player} ({score:.2f})")

        if low_score_players:
            for player, score in sorted(low_score_players, key=lambda x: x[1]):
                player_info = get_player_info(player)
                print(f"  - [{player_info.get('team','N/A')}] {player_info.get('rank','')} {player} ({score:.2f})")

        exit(0)

    elif command in {"leaderboard", "lb"}:
        # Get leaderboard data
        s.sendall(b'get_leaderboard')
        response = recv(s)

        if not response:
            print("[-] No leaderboard data available")
            exit(0)

        leaderboard = json.loads(response.decode())
        print("Leaderboard:")
        for player, score in leaderboard:
            print(f"  {player}: {score:.2f}")

        exit(0)

    elif command == "unlock":
        if is_running():
            print("[+] Lock file found, removing...")
            os.remove('players.lock')
            print("[+] Lock file removed")
        else:
            print("[-] No lock file found")
        exit(0)

    # Default case - show help for invalid commands
    print(f"Unknown command: {command}")
    print("Use 'help' to see available commands")
    exit(0)

def is_running():
    s.sendall(f'is_connected|{client_player}'.encode())
    response = recv(s)
    if response == b'True':
        return True
    return False

# Function to handle session token management
def get_session_token():
    """Get stored session token or return None"""
    if os.path.exists(token_path):
        try:
            with open(token_path, 'r') as f:
                token_data = json.load(f)

            # Check if token is still valid (with 5 minute buffer)
            if token_data.get('expiry', 0) > time.time() + 300:
                return token_data
        except:
            pass

    return None

def save_session_token(token_data):
    """Save session token to file"""

    with open(token_path, 'w') as f:
        json.dump(token_data, f)

def connect():
    global username, session_token, s, connected

    try: s.connect(addr)
    except:
        print(f"[-] Failed to connect to server: {addr}")
        exit(0)

    connected = is_running()

    # First try to authenticate with cached session token
    session_token = get_session_token()
    if session_token:
        try:
            username = session_token.get('username', 'Unknown')  # Get username from token
            s.sendall(f'auth|{username}|{session_token["token"]}|{client_player}'.encode())
            response = recv(s)

            if response == b'ok':
                return True

            # Session token failed, close and retry with full auth
            s.close()
            s = socket.socket()
            print(f"[!] Session token expired, performing full authentication...")
        except Exception as e:
            print(f"[!] Session token error: {e}")
            s = socket.socket()  # Reset socket

    # Full OAuth authentication through web.py
    try:
        # Get a fresh token using web.py's authenticate
        auth_result = authenticate()
        if not auth_result:
            print("[-] Authentication failed - could not get Discord credentials")
            exit(0)

        username, discord_token = auth_result

        # Connect to game server
        try: s.connect(addr)
        except Exception as e: print(e)

        # Send authentication request
        s.sendall(f'auth|{username}|{discord_token}|{client_player}'.encode())
        response = recv(s, 2)

        # Handle JSON response for session tokens
        try:
            response_data = json.loads(response.decode())
            if response_data.get('status') == 'ok':
                session_token = {
                    'token': response_data.get('session_token'),
                    'username': username,
                    'expiry': time.time() + response_data.get('expires_in', 86400)
                }
                # Save the token
                save_session_token(session_token)
                print(f"[+] Authentication successful as {username}")
                return True

        except json.JSONDecodeError:
            # Handle plain response
            if response == b'ok':
                print(f"[+] Authentication successful as {username} (no session support)")
                return True
            else:
                print(f"[-] Authentication failed: '{response.decode()}'")
                exit(0)

        print(f"[-] Failed to authenticate: {response.decode()}")
        exit(0)

    except Exception as e:
        print(f"[-] Authentication error: {e}")
        exit(0)

def main():
    global username, s, players, connected

    # Connect to server
    connect()

    # Get players
    try: players = fetch_players()
    except:
        print('[-] Failed to fetch players')
        exit(0)

    # CLI
    parse_command(sys.argv)

    # Lock to prevent multiple scanning instances
    if connected:
        exit(0)

    # Scan players
    print(f'[!] Thank you for contributing, {username}!')

    with EventQueue() as queue:
        queue.register_add_entity_listener()
        queue.register_chat_listener()
        while True:
            event = queue.get()

            if event.type == EventType.ADD_ENTITY:
                entity = event.entity

                if entity.type != 'entity.minecraft.player':
                    continue


                player = entity.name.strip()
                if player.count(' ') < 2:
                    continue

                player_rank, player_name = player.split(' ')[:2]

                if player_rank == 'MEMBER':
                    continue

                if entity.name not in players:
                    submit_player(player_name, rank=player_rank)

            elif event.type == EventType.CHAT:
                message = event.message

                if message in _printed:
                    _printed.remove(message)
                    continue

                if message.startswith('> '):
                    continue

                if not (message.startswith('[') and ']' in message):
                    continue

                if (message.startswith('[DEBUG]:')
                        or message.startswith('[Meteor]')
                        or message.startswith('[Server]')
                        or message.startswith('[Coinflip]')
                        or message.startswith('[BLISS]')
                    ):
                    continue

                if any([i in message for i in {'\n','\r'}]):
                    continue

                try:
                    team, rank, player = message.split(' ')[:3]
                    team = team.strip('[]').strip()
                    rank = rank.strip()
                    player = player.strip()
                    if rank == 'MEMBER':
                        continue

                except Exception as e:
                    print(f"[-] Failed to parse message: {message}: {e}")

                if ' ' in team or ' ' in rank or ' ' in player:
                    continue

                if len(team) < 3 or len(rank) < 2 or len(player) < 4:
                    continue

                if rank not in { # All Pissrealm ranks
                        'PRO', 'VIP', 'BOOSTER', 'HERO', 'LEGEND', 'SUPREME',
                        'TRAINEE', 'HELPER', 'MOD', 'ADMIN', 'CO-OWNER', 'OWNER'
                    }:
                    continue

                submit_player(player, team, rank)

if __name__ == '__main__':
    main()
