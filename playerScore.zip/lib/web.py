from flask import request, session
from urllib.parse import quote
from threading import Thread
import time as t
import flask.logging
import webview
import secrets
import logging
import zenora
import flask
import os

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

os.environ['Path'] = ''

app:flask.Flask = flask.Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(16)

client_id = 1352987777784086588
secret = 'Gj--9xgtrZyt-pHUHxYIYA_O7XEFoKuU'
token = 'MTM1Mjk4Nzc3Nzc4NDA4NjU4OA.GiCleM.DD1s9GU1JlhkLGvZFJ6JCcWjzTSgJupRamyPJg'
redirect_uri = 'http://localhost:5000/'
oauth_url = f"https://discord.com/api/oauth2/authorize?client_id={client_id}&redirect_uri={quote(redirect_uri)}&response_type=code&scope=identify"

client = zenora.APIClient(token, client_secret=secret)

token = None

def destroy():
    t.sleep(1)
    window.destroy()

@app.route('/')
def index():
    global token
    if "access_token" in session:
        token = session['access_token']
        Thread(target=destroy,daemon=True).start()
        return ""

    code = request.args.get("code")
    if not code:
        return flask.redirect(oauth_url)
    access_token = client.oauth.get_access_token(
        code, redirect_uri=redirect_uri
    ).access_token
    session["access_token"] = access_token
    return app.redirect('/')

def login():
    global window
    Thread(target=app.run, daemon=True).start()

    window = webview.create_window('Discord Authentication', oauth_url, width=800, height=600)
    webview.start(private_mode=False)

    with open(f'../playerScore/token.txt', 'w') as f:
        f.write(token)

    return token

def authenticate():
    os.makedirs(f'../playerScore', exist_ok=True)
    if os.path.exists(f'../playerScore/token.txt'):
        with open(f'../playerScore/token.txt', 'r') as f:
            token = f.read().strip()
    else:
        token = login()

    try:
        client = zenora.APIClient(token, bearer=True)
    except zenora.BadTokenError:
        token = login()
        try: client = zenora.APIClient(token, bearer=True)
        except:
            print('[-] Failed to authenticate')
            return None
    except:
        print('[-] Failed to authenticate')
        return None

    username = client.users.get_current_user().username

    return username, token


